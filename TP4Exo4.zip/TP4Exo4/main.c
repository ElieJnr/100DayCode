#include <stdio.h>
#include "fonctions.h"

int main()
{
    affichersolde();
    Returnmenu();
    return 0;
}